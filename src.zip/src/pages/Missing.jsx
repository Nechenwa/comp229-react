import React from 'react'

function Missing() {
  return (
    <div>
      Page not found
    </div>
  )
}

export default Missing
