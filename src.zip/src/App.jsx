import Layout from './pages/Layout'
import './index.css'
import './tailwind.css';
function App() {
  return <Layout />
}

export default App
